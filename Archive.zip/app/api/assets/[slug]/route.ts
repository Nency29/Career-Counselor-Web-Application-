import { readFile } from 'fs/promises'
import { NextRequest, NextResponse } from 'next/server'
import path from 'path'
import 'encoding'

export async function GET(
	_: NextRequest,
	{ params }: { params: { slug: string } }
) {
	try {
		const filePath = path.join(process.cwd(), 'public', 'assets', params.slug)

		const file = await readFile(filePath)
		return new Response(file, {
			headers: {
				'Content-Type': 'application/pdf',
				'Content-Disposition': `inline; filename="${params.slug}"`,
			},
		})
	} catch (error) {
		return NextResponse.json(
			{ message: (error as Error).message },
			{ status: 500 }
		)
	}
}
