import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { genSalt, hash } from 'bcrypt'

export async function POST(req: NextRequest) {
	try {
		const { fullName, email, password } = await req.json()

		// check if the user already exists
		const existing = await prisma.user.findUnique({ where: { email } })
		if (existing)
			return NextResponse.json(
				{ message: 'User already registered.' },
				{ status: 400 }
			)

		// create new user
		await prisma.user.create({
			data: {
				fullName,
				email,
				password: await hash(password, await genSalt()),
			},
		})

		return NextResponse.json({}, { status: 201 })
	} catch (error) {
		return NextResponse.json(
			{ message: (error as Error).message },
			{ status: 500 }
		)
	}
}
