import { getServerSession } from 'next-auth'
import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export async function POST(req: NextRequest, res: NextResponse) {
	try {
		const { hash } = await req.json()
		const session = await getServerSession()
		const user = await prisma.user.findUnique({
			where: { email: session?.user?.email! },
		})

		await prisma.user.update({
			where: { id: user?.id },
			data: {
				premiumSubscription: {
					create: {
						hash,
						status: 'paid',
					},
				},
			},
		})

		return NextResponse.json({}, { status: 201 })
	} catch (error) {
		return NextResponse.json(
			{ message: (error as Error).message },
			{ status: 500 }
		)
	}
}
