import { prisma } from '@/lib/prisma'
import { getServerSession } from 'next-auth'
import { NextRequest, NextResponse } from 'next/server'

export async function POST(req: NextRequest) {
	try {
		const { educationalQualification, workExperience } = await req.json()

		const session = await getServerSession()
		const user = await prisma.user.findUnique({
			where: { email: session?.user?.email! },
			select: {
				id: true,
				fullName: true,
				email: true,
			},
		})

		const resume = await prisma.resume.create({
			data: {
				user: { connect: { id: user?.id } },
				educationalQualification,
				workExperience,
			},
		})

		return NextResponse.json({ resume, user }, { status: 201 })
	} catch (error) {
		return NextResponse.json(
			{ message: (error as Error).message },
			{ status: 500 }
		)
	}
}
