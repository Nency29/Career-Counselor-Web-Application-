import 'encoding'
import { writeFile, mkdir } from 'fs/promises'
import { NextRequest, NextResponse } from 'next/server'
import path from 'path'

export async function POST(req: NextRequest) {
	try {
		const data = await req.formData()
		const file: File | null = data.get('file') as unknown as File

		if (!file) return NextResponse.json({}, { status: 400 })

		const bytes = await file.arrayBuffer()
		const buffer = Buffer.from(bytes)

		const filePath = path.join(process.cwd(), 'public', 'assets', file.name)
		await mkdir(path.dirname(filePath), { recursive: true })
		await writeFile(filePath, buffer)
		return NextResponse.json({}, { status: 201 })
	} catch (error) {
		return NextResponse.json(
			{ message: (error as Error).message },
			{ status: 500 }
		)
	}
}
