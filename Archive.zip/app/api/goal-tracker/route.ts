import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { getServerSession } from 'next-auth'

export async function POST(req: NextRequest) {
	try {
		const { title, status } = await req.json()

		const session = await getServerSession()
		const user = await prisma.user.findUnique({
			where: { email: session?.user?.email! },
		})

		await prisma.task.create({
			data: {
				user: { connect: { id: user?.id } },
				title,
				status,
			},
		})

		return NextResponse.json({}, { status: 201 })
	} catch (error) {
		return NextResponse.json(
			{ message: (error as Error).message },
			{ status: 500 }
		)
	}
}
