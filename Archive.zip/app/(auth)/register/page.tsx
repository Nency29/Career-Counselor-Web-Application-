import RegisterForm from '@/components/forms/register-form'
import Link from 'next/link'

export default function RegisterPage() {
	return (
		<div className="max-w-sm w-full">
			<h1 className="mb-5 font-medium text-xl text-center">
				Create new account
			</h1>

			<RegisterForm />

			<div className="mt-5 text-center">
				Already registered?{' '}
				<Link href="/login" className="underline text-indigo-500">
					Login
				</Link>
			</div>
		</div>
	)
}
