import LoginForm from '@/components/forms/login-form'
import Link from 'next/link'

export default function LoginPage() {
	return (
		<div className="max-w-sm w-full">
			<h1 className="mb-5 font-medium text-xl text-center">Welcome back</h1>

			<LoginForm />

			<div className="mt-5 text-center">
				Not registered?{' '}
				<Link href="/register" className="underline text-indigo-500">
					Create new account
				</Link>
			</div>
		</div>
	)
}
