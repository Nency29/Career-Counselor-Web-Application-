import PaymentButton from '@/components/inc/payment-button'
import { prisma } from '@/lib/prisma'
import { getServerSession } from 'next-auth'
import Link from 'next/link'

export default async function UpgradeProPage() {
	const session = await getServerSession()

	let proStatus = null
	if (session)
		proStatus = await prisma.user
			.findUnique({
				where: { email: session?.user?.email! },
			})
			.premiumSubscription({ select: { status: true } })

	return (
		<div className="grid place-items-center">
			{proStatus && proStatus?.status === 'paid' ? (
				<p>
					You are already a premium member. Go{' '}
					<Link href="/" replace className="underline text-indigo-500">
						home
					</Link>
				</p>
			) : (
				<PaymentButton />
			)}
		</div>
	)
}
