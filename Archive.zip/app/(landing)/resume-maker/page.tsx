import ResumeMakerForm from '@/components/forms/resume-maker-form'
import {
	Table,
	TableBody,
	TableCaption,
	TableCell,
	TableHead,
	TableHeader,
	TableRow,
} from '@/components/ui/table'
import { prisma } from '@/lib/prisma'
import { getServerSession } from 'next-auth'

export default async function ResumeMakerPage() {
	const session = await getServerSession()

	const user = await prisma.user.findUnique({
		where: { email: session?.user?.email! },
	})

	const resumes = await prisma.resume.findMany({ where: { userId: user?.id } })

	return (
		<div>
			<div>
				<h2 className="text-xl font-medium mb-5">Create a resume</h2>

				<ResumeMakerForm />
			</div>

			<div className="mt-8">
				<h2 className="text-xl font-medium mb-5">Your resumes</h2>

				{resumes.length > 0 ? (
					<Table>
						<TableCaption>A list of resumes you have added.</TableCaption>
						<TableHeader>
							<TableRow>
								<TableHead>Name</TableHead>
								<TableHead>Action</TableHead>
							</TableRow>
						</TableHeader>
						<TableBody>
							{resumes.map((resume) => (
								<TableRow key={resume.id}>
									<TableCell className="font-medium">
										resume-{resume.id}.pdf
									</TableCell>
									<TableCell>
										<a
											href={`/assets/resume-${resume.id}.pdf`}
											className="underline text-indigo-500"
											target="_blank"
											rel="noopener noreferrer"
										>
											View
										</a>
									</TableCell>
								</TableRow>
							))}
						</TableBody>
					</Table>
				) : (
					<div>No resumes added.</div>
				)}
			</div>
		</div>
	)
}
