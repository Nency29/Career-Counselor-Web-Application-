import LogoutButton from '@/components/inc/logout-button'
import {
	DropdownMenu,
	DropdownMenuContent,
	DropdownMenuItem,
	DropdownMenuLabel,
	DropdownMenuSeparator,
	DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { prisma } from '@/lib/prisma'
import { Album, Facebook, Gem, Goal, Instagram, Twitter } from 'lucide-react'
import { getServerSession } from 'next-auth'
import Link from 'next/link'

export default async function LandingLayout({
	children,
}: {
	children: React.ReactNode
}) {
	const session = await getServerSession()

	let proStatus = null
	if (session)
		proStatus = await prisma.user
			.findUnique({
				where: { email: session?.user?.email! },
			})
			.premiumSubscription({ select: { status: true } })

	return (
		<div className="min-h-screen flex flex-col">
			<header className="p-5 flex items-center justify-between">
				<Link href="/">CareerCounsellor</Link>

				{session ? (
					<DropdownMenu>
						<DropdownMenuTrigger className="border font-medium rounded py-2 px-3">
							{session?.user?.email}
						</DropdownMenuTrigger>
						<DropdownMenuContent align="end" className="w-48">
							<DropdownMenuLabel>My Account</DropdownMenuLabel>
							<DropdownMenuSeparator />
							<DropdownMenuItem asChild>
								<Link href="/goal-tracker">
									<Goal className="w-4 h-4 mr-2 inline" /> Goal tracker
								</Link>
							</DropdownMenuItem>
							<DropdownMenuItem asChild>
								<Link href="/resume-maker">
									<Album className="w-4 h-4 mr-2 inline" /> Resume maker
								</Link>
							</DropdownMenuItem>
							<DropdownMenuSeparator />
							{proStatus && proStatus?.status === 'paid' ? (
								<></>
							) : (
								<>
									<DropdownMenuItem asChild>
										<Link href="/upgrade-pro">
											<Gem className="w-4 h-4 mr-2 inline" /> Upgrade to Pro
										</Link>
									</DropdownMenuItem>
									<DropdownMenuSeparator />
								</>
							)}
							<LogoutButton />
						</DropdownMenuContent>
					</DropdownMenu>
				) : (
					<Link href="/login" className="border font-medium rounded py-2 px-3">
						Login
					</Link>
				)}
			</header>

			<main className="flex-grow py-8 container">{children}</main>

			<footer className="p-5 flex items-center justify-between flex-wrap">
				<p>&copy; 2023</p>
				<div className="flex items-center gap-x-5">
					<a
						href="https://facebook.com"
						target="_blank"
						rel="noopener noreferrer"
					>
						<Facebook className="w-4 h-4" />
					</a>
					<a href="https://x.com" target="_blank" rel="noopener noreferrer">
						<Twitter className="w-4 h-4" />
					</a>
					<a
						href="https://instagram.com"
						target="_blank"
						rel="noopener noreferrer"
					>
						<Instagram className="w-4 h-4" />
					</a>
				</div>
			</footer>
		</div>
	)
}
