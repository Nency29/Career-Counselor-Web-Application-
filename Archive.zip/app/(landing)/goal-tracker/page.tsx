import AddTaskForm from '@/components/forms/add-task-form'
import {
	Table,
	TableBody,
	TableCaption,
	TableCell,
	TableHead,
	TableHeader,
	TableRow,
} from '@/components/ui/table'
import { prisma } from '@/lib/prisma'
import { getServerSession } from 'next-auth'

export default async function GoalTracker() {
	const session = await getServerSession()

	const user = await prisma.user.findUnique({
		where: { email: session?.user?.email! },
	})

	const tasks = await prisma.task.findMany({ where: { userId: user?.id } })

	return (
		<div>
			<div>
				<h2 className="text-xl font-medium mb-5">Add a new goal</h2>

				<AddTaskForm />
			</div>

			<div className="mt-8">
				<h2 className="text-xl font-medium mb-5">Your goals</h2>

				{tasks?.length > 0 ? (
					<Table>
						<TableCaption>A list of goals you have added.</TableCaption>
						<TableHeader>
							<TableRow>
								<TableHead>Title</TableHead>
								<TableHead>Status</TableHead>
							</TableRow>
						</TableHeader>
						<TableBody>
							{tasks.map((task) => (
								<TableRow key={task.id}>
									<TableCell className="font-medium">{task.title}</TableCell>
									<TableCell>{task.status}</TableCell>
								</TableRow>
							))}
						</TableBody>
					</Table>
				) : (
					<div>No goals added</div>
				)}
			</div>
		</div>
	)
}
