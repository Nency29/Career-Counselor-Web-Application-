import { buttonVariants } from '@/components/ui/button'
import { FileText, Gem, Goal } from 'lucide-react'
import { getServerSession } from 'next-auth'
import Link from 'next/link'

export default async function HomePage() {
	const session = await getServerSession()
	let proStatus = null
	if (session)
		proStatus = await prisma.user
			.findUnique({
				where: { email: session?.user?.email! },
			})
			.premiumSubscription({ select: { status: true } })

	return (
		<div>
			<section className="grid place-items-center max-w-screen-md mx-auto text-center gap-y-5 py-16">
				<h4 className="sm:text-lg">
					Hello, {session?.user?.email ?? 'world'}!
				</h4>
				<h1 className="text-2xl sm:text-5xl font-bold mb-3">
					Discover CareerCounsellor - your onestop solution to all your career
					needs.
				</h1>
				<Link
					href={session?.user?.email ? '/goal-tracker' : '/login'}
					className={buttonVariants()}
				>
					Get started
				</Link>
			</section>

			<section className="max-w-screen-lg mx-auto py-16">
				<section className="mb-8 text-center space-y-2.5">
					<h2 className="text-xl sm:text-3xl font-bold">Services</h2>
					<p>Things you can do using CareerCounsellor</p>
				</section>
				<div className="grid sm:grid-cols-2 gap-5 [&>div]:border [&>div]:rounded-lg [&>div]:p-5 [&>div]:space-y-3.5 sm:[&>div>h6]:text-lg [&>div>h6]:font-semibold">
					<div>
						<Goal className="w-8 h-8" />
						<h6>Goal tracking</h6>
					</div>
					<div>
						<FileText className="w-8 h-8" />
						<h6>Resume making</h6>
					</div>
				</div>
			</section>

			{proStatus && proStatus?.status === 'paid' ? (
				<></>
			) : (
				<section className="max-w-screen-lg mx-auto py-16 mt-16 rounded-lg bg-indigo-100 grid place-items-center">
					<h1 className="text-lg sm:text-3xl font-semibold">
						Get our premium features by{' '}
						<Link href="/upgrade-pro" className="text-indigo-500">
							<Gem className="w-6 h-6 inline mr-2" /> Upgrading to Pro
						</Link>
					</h1>
				</section>
			)}
		</div>
	)
}
