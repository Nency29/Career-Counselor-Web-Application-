'use client'

import { zodResolver } from '@hookform/resolvers/zod'
import {
	Document,
	Page,
	StyleSheet,
	Text,
	View,
	pdf,
} from '@react-pdf/renderer'
import { Loader2 } from 'lucide-react'
import { useRouter } from 'next/navigation'
import { useForm } from 'react-hook-form'
import * as z from 'zod'
import { Button } from '../ui/button'
import { Form, FormControl, FormField, FormItem, FormLabel } from '../ui/form'
import { Textarea } from '../ui/textarea'

const formSchema = z
	.object({
		educationalQualification: z
			.string()
			.min(1, 'Educational qualification is required'),
		workExperience: z.string().min(1, 'Work experience is required'),
	})
	.required()

export default function ResumeMakerForm() {
	const form = useForm<z.infer<typeof formSchema>>({
		resolver: zodResolver(formSchema),
	})

	const router = useRouter()
	async function onSubmit(values: z.infer<typeof formSchema>) {
		const res = await fetch('/api/resume-maker', {
			method: 'POST',
			body: JSON.stringify(values),
		})

		if (res.status === 201) {
			form.setValue('educationalQualification', ''),
				form.setValue('workExperience', '')

			const { resume, user } = await res.json()

			const styles = StyleSheet.create({
				page: {
					fontFamily: 'Helvetica',
					fontSize: 12,
					padding: 20,
				},
				section: {
					marginBottom: 10,
				},
			})

			const ResumePdf = (
				<Document>
					<Page size={'A4'} style={styles.page}>
						<View style={styles.section}>
							<Text>Name:</Text>
							<Text>{user?.fullName}</Text>
						</View>
						<View style={styles.section}>
							<Text>Email:</Text>
							<Text>{user?.email}</Text>
						</View>
						<View style={styles.section}>
							<Text>Education Qualifications:</Text>
							<Text>{resume?.educationalQualification}</Text>
						</View>
						<View style={styles.section}>
							<Text>Work Experience:</Text>
							<Text>{resume?.workExperience}</Text>
						</View>
					</Page>
				</Document>
			)

			const pdfBlob = await pdf(ResumePdf).toBlob()
			const formData = new FormData()
			formData.append('file', pdfBlob, `resume-${resume?.id}.pdf`)
			await fetch('/api/resume-maker/upload', {
				method: 'POST',
				body: formData,
			})
			return router.refresh()
		}
	}

	return (
		<Form {...form}>
			<form onSubmit={form.handleSubmit(onSubmit)} className="space-y-3 w-full">
				<FormField
					control={form.control}
					name="educationalQualification"
					render={({ field }) => (
						<FormItem>
							<FormLabel>Educational qualification</FormLabel>
							<FormControl>
								<Textarea {...field} rows={5} className="resize-none" />
							</FormControl>
						</FormItem>
					)}
				/>

				<FormField
					control={form.control}
					name="workExperience"
					render={({ field }) => (
						<FormItem>
							<FormLabel>Work experience</FormLabel>
							<FormControl>
								<Textarea {...field} rows={5} className="resize-none" />
							</FormControl>
						</FormItem>
					)}
				/>

				<Button
					type="submit"
					disabled={form.formState.isSubmitting}
					className="m-0"
				>
					{form.formState.isSubmitting && (
						<Loader2 className="mr-2 h-4 w-4 animate-spin" />
					)}
					{form.formState.isSubmitting ? 'Please wait...' : 'Submit'}
				</Button>
			</form>
		</Form>
	)
}
