'use client'

import { zodResolver } from '@hookform/resolvers/zod'
import { Loader2 } from 'lucide-react'
import { useRouter } from 'next/navigation'
import { useForm } from 'react-hook-form'
import * as z from 'zod'
import { Button } from '../ui/button'
import { Form, FormControl, FormField, FormItem } from '../ui/form'
import { Input } from '../ui/input'
import {
	Select,
	SelectContent,
	SelectItem,
	SelectTrigger,
	SelectValue,
} from '../ui/select'

const formSchema = z
	.object({
		title: z.string().min(1, 'Title is required'),
		status: z.string().min(1, 'Status is required'),
	})
	.required()

export default function AddTaskForm() {
	const form = useForm<z.infer<typeof formSchema>>({
		resolver: zodResolver(formSchema),
	})

	const router = useRouter()
	async function onSubmit(values: z.infer<typeof formSchema>) {
		const res = await fetch('/api/goal-tracker', {
			method: 'POST',
			body: JSON.stringify(values),
		})

		if (res.status === 201) {
			form.setValue('title', '')
			form.setValue('status', '')
			return router.refresh()
		}
	}

	return (
		<Form {...form}>
			<form
				onSubmit={form.handleSubmit(onSubmit)}
				className="flex items-center gap-x-2.5"
			>
				<FormField
					control={form.control}
					name="title"
					render={({ field }) => (
						<FormItem>
							<FormControl>
								<Input {...field} placeholder="Title" />
							</FormControl>
						</FormItem>
					)}
				/>

				<FormField
					control={form.control}
					name="status"
					render={({ field }) => (
						<FormItem className="w-32">
							<Select onValueChange={field.onChange} defaultValue={field.value}>
								<FormControl>
									<SelectTrigger>
										<SelectValue placeholder="Status" />
									</SelectTrigger>
								</FormControl>
								<SelectContent>
									<SelectItem value="todo">Todo</SelectItem>
									<SelectItem value="in_progress">In progress</SelectItem>
									<SelectItem value="cancelled">Cancelled</SelectItem>
								</SelectContent>
							</Select>
						</FormItem>
					)}
				/>

				<Button
					type="submit"
					disabled={form.formState.isSubmitting}
					className="m-0"
				>
					{form.formState.isSubmitting && (
						<Loader2 className="mr-2 h-4 w-4 animate-spin" />
					)}
					{form.formState.isSubmitting ? 'Please wait...' : 'Submit'}
				</Button>
			</form>
		</Form>
	)
}
