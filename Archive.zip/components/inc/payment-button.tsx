'use client'

import { Gem } from 'lucide-react'
import { ethers } from 'ethers'
import { buttonVariants } from '../ui/button'
import { useToast } from '../ui/use-toast'
import { useRouter } from 'next/navigation'

export default function PaymentButton() {
	const { toast } = useToast()
	const router = useRouter()

	async function initiatePayment() {
		try {
			// @ts-ignore
			if (window && window.ethereum) {
				// @ts-ignore
				await window.ethereum.send('eth_requestAccounts')
				// @ts-ignore
				const provider = new ethers.BrowserProvider(window.ethereum)
				const signer = await provider.getSigner()
				const tx = await signer.sendTransaction({
					to: '0x4D58f96938390B71F9518cd2973943e9f70C1484',
					value: ethers.parseEther('0.01'),
				})
				if (tx.hash) {
					const res = await fetch('/api/process-payment', {
						method: 'post',
						body: JSON.stringify({ hash: tx.hash }),
					})

					if (res.status === 201) router.refresh()
				}
			} else {
				toast({
					description: 'Metamask not available.',
					variant: 'destructive',
				})
			}
		} catch (error) {
			toast({
				description: (error as Error).message,
				variant: 'destructive',
			})
		}
	}

	return (
		<button
			className={buttonVariants({ variant: 'outline' })}
			onClick={initiatePayment}
		>
			<Gem className="w-4 h-4 mr-2 inline" />
			Upgrade to Pro (0.01ETH)
		</button>
	)
}
