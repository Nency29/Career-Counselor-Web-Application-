'use client'

import { signOut } from 'next-auth/react'
import { DropdownMenuItem } from '../ui/dropdown-menu'
import { LogOut } from 'lucide-react'

export default function LogoutButton() {
	return (
		<DropdownMenuItem
			className="text-red-500"
			onClick={async () => await signOut()}
		>
			<LogOut className="w-4 h-4 mr-2 inline" /> Logout
		</DropdownMenuItem>
	)
}
