import { NextAuthOptions } from 'next-auth'
import Credentials from 'next-auth/providers/credentials'
import { prisma } from '@/lib/prisma'
import { compare } from 'bcrypt'

export const authOptions: NextAuthOptions = {
	providers: [
		Credentials({
			name: 'credentials',
			credentials: {
				email: { type: 'email' },
				password: { type: 'password' },
			},
			async authorize(credentials) {
				const { email, password } = credentials ?? {}

				const user = await prisma.user.findUnique({ where: { email } })

				if (!user || !(await compare(password!, user.password)))
					throw new Error('Invalid credentials.')

				return user
			},
		}),
	],
}
